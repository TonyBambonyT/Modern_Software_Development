import tkinter as tk
from tkinter import messagebox
import requests
import json


# Практическая работа 11.
# Получение данных о владельце репозитория через GitHub API.

def get_github_data():
    # Имя из поля ввода (firehol)
    user_name = entry_name.get()

    if not user_name:
        messagebox.showwarning("Внимание", "Введите имя пользователя или организации!")
        return

    # Формируем URL /users/ для получения company и email
    url = f"https://api.github.com/users/{user_name}"

    try:
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            # Словарь нужных полей с .get() (None, если поля нет)
            result_data = {
                'company': data.get('company'),
                'created_at': data.get('created_at'),
                'email': data.get('email'),
                'id': data.get('id'),
                'name': data.get('name'),
                'url': data.get('url')
            }

            filename = "11_git_result.json"
            with open(filename, "w") as f:
                json.dump(result_data, f, indent=4)

            messagebox.showinfo("Успех", f"Данные сохранены в файл {filename}")

            # Можно вывести в консоль для проверки
            print("Полученные данные:")
            print(result_data)

        else:
            messagebox.showerror("Ошибка", "Пользователь не найден или ошибка соединения")

    except Exception as e:
        messagebox.showerror("Ошибка", f"Что-то пошло не так: {e}")


window = tk.Tk()
window.title("Тарарыков Антон Алексеевич")
window.geometry("400x200")

lbl = tk.Label(window, text="Введите имя владельца репозитория (например, firehol):")
lbl.pack(pady=10)

entry_name = tk.Entry(window, width=30)
entry_name.pack(pady=5)

btn = tk.Button(window, text="Получить JSON", command=get_github_data)
btn.pack(pady=20)

window.mainloop()