# Практическая работа 9. Вариант 6.
# Ввод и вывод данных через файлы.

INPUT_FILE = "9_Тарарыков_Антон_Алексеевич_ЗИТ-25м_vvod.txt"
OUTPUT_FILE = "9_Тарарыков_Антон_Алексеевич_ЗИТ-25м_vivod.txt"

def solve():
    with open(INPUT_FILE, "r") as f_in:
        lines = f_in.readlines()

    with open(OUTPUT_FILE, "w") as f_out:

        f_out.write("--- Задание 1 ---\n")

        # Читаем размер первой матрицы; strip() удаляет пробелы и перенос строки.
        n1 = int(lines[0].strip())

        matrix1 = []
        for i in range(n1):
            row_str = lines[1 + i].strip()
            row = list(map(int, row_str.split()))
            matrix1.append(row)

        f_out.write("Исходная матрица:\n")
        for row in matrix1:
            f_out.write(str(row) + "\n")

        f_out.write("Максимумы в строках: ")
        for row in matrix1:
            max_in_row = row[0]
            for elem in row:
                if elem > max_in_row:
                    max_in_row = elem
            f_out.write(str(max_in_row) + " ")
        f_out.write("\n")

        f_out.write("Минимумы в столбцах: ")
        for j in range(n1):
            min_in_col = matrix1[0][j]
            for i in range(n1):
                if matrix1[i][j] < min_in_col:
                    min_in_col = matrix1[i][j]
            f_out.write(str(min_in_col) + " ")
        f_out.write("\n\n")

        f_out.write("--- Задание 2 ---\n")

        # Индекс строки размера второй матрицы: 1 + n1
        idx_start_2 = 1 + n1
        n2 = int(lines[idx_start_2].strip())

        matrix2 = []
        for i in range(n2):
            row_str = lines[idx_start_2 + 1 + i].strip()
            row = list(map(float, row_str.split()))
            matrix2.append(row)

        center = n2 // 2
        max_val = matrix2[center][center]
        max_i = center
        max_j = center

        for i in range(n2):
            if matrix2[i][i] > max_val:
                max_val = matrix2[i][i]
                max_i = i
                max_j = i
            side_j = n2 - 1 - i
            if matrix2[i][side_j] > max_val:
                max_val = matrix2[i][side_j]
                max_i = i
                max_j = side_j

        matrix2[max_i][max_j], matrix2[center][center] = matrix2[center][center], matrix2[max_i][max_j]

        f_out.write(f"Матрица после замены (макс {max_val} перемещен в центр):\n")
        for row in matrix2:
            f_out.write(str(row) + "\n")

    print("Готово! Результаты записаны в файл", OUTPUT_FILE)


# Запуск решения
try:
    solve()
except FileNotFoundError:
    print("Ошибка: Файл с входными данными не найден!")
    print("Создайте файл", INPUT_FILE, "с данными матриц.")